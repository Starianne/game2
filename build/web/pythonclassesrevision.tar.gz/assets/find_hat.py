import pygame
from event_dialogue import EventDialogue


def find_hat_event(game_state, font, screen_size, screen=None):
    background = pygame.image.load("graphics/backgrounds/forest.png").convert()
    portraits = {
        "Goob": pygame.image.load("graphics/portraits/goob_sprite.png").convert_alpha(),
    }

    event_dialogue = {
        "start": {
            "character": "Goob",
            "text": "Huh. A hat.",
            "options": [],
            "next_states": ["decision"],
        },
        "decision": {
            "character": "Goob",
            "text": "No one's using it.",
            "options": [],
            "next_states": ["take_hat"],
        },
        "take_hat": {
            "character": "Goob",
            "text": "I look better already.",
            "options": [],
            "next_states": [],
            "reward": lambda gs: gs.add_hats(1),
        },
    }

    event = EventDialogue(game_state, event_dialogue, font, screen_size, background=background, screen=screen)
    event.portraits = portraits
    return event